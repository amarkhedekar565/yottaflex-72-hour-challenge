# IoT Energy Waste Tracking System

## Setup and Execution
1. Install dependencies:
   ```bash
   pip install pandas numpy pytest
   ```
2. Run data generation:
   ```bash
   python src/generator.py
   ```
3. Execute validation tests:
   ```bash
   pytest tests/
   ```
