-- Core Industrial Plant Topography
CREATE TABLE plants (
    plant_id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(255) NOT NULL
);

-- Meter Topography & Sensor Registries
CREATE TABLE meters (
    meter_id VARCHAR(50) PRIMARY KEY,
    plant_id VARCHAR(50) REFERENCES plants(plant_id)
);

-- Production Machinery Registries
CREATE TABLE machines (
    machine_id VARCHAR(50) PRIMARY KEY,
    meter_id VARCHAR(50) REFERENCES meters(meter_id),
    idle_kw DOUBLE PRECISION NOT NULL,
    active_kw_per_unit_rate DOUBLE PRECISION NOT NULL
);

-- Shift Management Logs
CREATE TABLE shifts (
    shift_id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    start_hour INT NOT NULL,
    end_hour INT NOT NULL
);

-- Utility Financial Tariff Matrix
CREATE TABLE tariffs (
    tariff_id VARCHAR(50) PRIMARY KEY,
    hour INT NOT NULL,
    minute INT NOT NULL,
    window_name VARCHAR(50) NOT NULL,
    rate_per_kwh DOUBLE PRECISION NOT NULL
);

-- Environmental Context Tracking
CREATE TABLE weather_observations (
    weather_id VARCHAR(50) PRIMARY KEY,
    timestamp TIMESTAMP NOT NULL,
    temperature DOUBLE PRECISION NOT NULL
);

-- Batch Execution Tracking
CREATE TABLE production_batches (
    batch_id VARCHAR(50) PRIMARY KEY,
    machine_id VARCHAR(50) REFERENCES machines(machine_id),
    start_time TIMESTAMP NOT NULL,
    end_time TIMESTAMP NOT NULL,
    units_produced INT NOT NULL
);

-- High-Frequency Metric Telemetry Staging
CREATE TABLE energy_readings (
    reading_id VARCHAR(100) PRIMARY KEY,
    meter_id VARCHAR(50) REFERENCES meters(meter_id),
    timestamp TIMESTAMP NOT NULL,
    kwh_consumed DOUBLE PRECISION NOT NULL,
    kw_demand DOUBLE PRECISION NOT NULL
);

-- Asset Asset Integrity Logs
CREATE TABLE maintenance_events (
    event_id VARCHAR(50) PRIMARY KEY,
    machine_id VARCHAR(50) REFERENCES machines(machine_id),
    timestamp TIMESTAMP NOT NULL,
    event_type VARCHAR(100) NOT NULL
);

-- Actionable Insights Staging
CREATE TABLE recommendations (
    rec_id VARCHAR(50) PRIMARY KEY,
    meter_id VARCHAR(50) REFERENCES meters(meter_id),
    detected_at TIMESTAMP NOT NULL,
    measurable_baseline_kwh DOUBLE PRECISION NOT NULL,
    expected_savings_usd DOUBLE PRECISION NOT NULL,
    recommendation_notes TEXT NOT NULL
);
