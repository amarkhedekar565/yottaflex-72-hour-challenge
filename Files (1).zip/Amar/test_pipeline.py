import pytest
from src.generator import generate_pipeline

def test_deterministic_reproducibility():
    _, _, _, _, _, tel1, _, gt1 = generate_pipeline(seed=20261022)
    _, _, _, _, _, tel2, _, gt2 = generate_pipeline(seed=20261022)
    
    assert len(tel1) == len(tel2), "Row counts do not match!"
    assert tel1['kwh_consumed'].sum() == tel2['kwh_consumed'].sum(), "Checksum mismatch!"
    assert len(gt1) == len(gt2), "Ground truth length mismatch!"
