import os
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

def create_directory_structure():
    for folder in ['data/generated', 'temp']:
        if not os.path.exists(folder):
            os.makedirs(folder)

def generate_pipeline(seed=20261022, target_scale=1.0):
    np.random.seed(seed)
    
    num_plants = 2
    num_meters = int(20 * target_scale)
    num_machines = num_meters * 2 
    num_batches = int(2000 * target_scale)
    days_duration = 90
    
    start_date = datetime(2026, 1, 1, 0, 0, 0)
    timestamps = [start_date + timedelta(minutes=15 * i) for i in range(days_duration * 24 * 4)]
    
    plants = [{"plant_id": f"PLT-{i:03d}", "name": f"Industrial Complex Alpha {i}"} for i in range(1, num_plants + 1)]
    df_plants = pd.DataFrame(plants)
    
    meters = []
    for i in range(1, num_meters + 1):
        p_id = plants[(i % num_plants)]["plant_id"]
        meters.append({"meter_id": f"MTR-{p_id}-{i:03d}", "plant_id": p_id})
    df_meters = pd.DataFrame(meters)
    
    machines = []
    for i in range(1, num_machines + 1):
        m_idx = i % len(meters)
        m_id = meters[m_idx]["meter_id"]
        machines.append({
            "machine_id": f"MAC-{i:04d}",
            "meter_id": m_id,
            "idle_kw": float(np.random.uniform(5.0, 15.0)),
            "active_kw_per_unit_rate": float(np.random.uniform(1.2, 3.5))
        })
    df_machines = pd.DataFrame(machines)
    
    weather = []
    for ts in timestamps:
        hour = ts.hour
        base_temp = 15.0 + 10.0 * np.sin(np.pi * (hour - 6) / 12)
        temperature = base_temp + float(np.random.normal(0, 1.5))
        weather.append({
            "weather_id": f"WTH-{int(ts.timestamp())}",
            "timestamp": ts.strftime('%Y-%m-%d %H:%M:%S'),
            "temperature": round(temperature, 2)
        })
    df_weather = pd.DataFrame(weather)
    
    batches = []
    current_time_tracker = {m["machine_id"]: start_date for m in machines}
    for b_idx in range(1, num_batches + 1):
        mac_obj = machines[b_idx % len(machines)]
        m_id = mac_obj["machine_id"]
        b_start = current_time_tracker[m_id] + timedelta(minutes=int(np.random.choice([15, 30, 45])))
        duration_mins = int(np.random.choice([60, 120, 180]))
        b_end = b_start + timedelta(minutes=duration_mins)
        units = int(np.random.uniform(50, 300))
        
        batches.append({
            "batch_id": f"BATCH-2026-{b_idx:06d}",
            "machine_id": m_id,
            "start_time": b_start.strftime('%Y-%m-%d %H:%M:%S'),
            "end_time": b_end.strftime('%Y-%m-%d %H:%M:%S'),
            "units_produced": units
        })
        current_time_tracker[m_id] = b_end
    df_batches = pd.DataFrame(batches)
    
    telemetry = []
    ground_truth_anomalies = []
    
    df_batches['dt_start'] = pd.to_datetime(df_batches['start_time'])
    df_batches['dt_end'] = pd.to_datetime(df_batches['end_time'])
    
    for m_idx, m_row in df_meters.iterrows():
        met_id = m_row['meter_id']
        linked_macs = [m for m in machines if m['meter_id'] == met_id]
        
        for ts in timestamps:
            ts_str = ts.strftime('%Y-%m-%d %H:%M:%S')
            epoch_ts = int(ts.timestamp())
            r_id = f"ENG-{met_id}-{epoch_ts}"
            
            total_interval_kw = 0.0
            for mac in linked_macs:
                is_running = ((df_batches['machine_id'] == mac['machine_id']) & 
                              (df_batches['dt_start'] <= ts) & 
                              (df_batches['dt_end'] >= ts)).any()
                if is_running:
                    total_interval_kw += mac['idle_kw'] + mac['active_kw_per_unit_rate'] * 15.0
                else:
                    total_interval_kw += mac['idle_kw']
            
            if ts.hour in:
                total_interval_kw *= np.random.uniform(1.1, 1.3)
                
            kwh_val = total_interval_kw * 0.25
            anomaly_flag = "NONE"
            
            if m_idx == 0 and ts.hour == 12 and ts.minute == 0:
                kwh_val *= 3.5 
                anomaly_flag = "METER_TOTAL_DISCREPANCY"
            elif m_idx == 1 and ts.hour == 18 and ts.minute == 30:
                kwh_val = total_interval_kw 
                anomaly_flag = "KW_KWH_METRIC_CONVERSION_ERROR"
                
            if anomaly_flag != "NONE":
                ground_truth_anomalies.append({
                    "target_id": r_id,
                    "meter_id": met_id,
                    "timestamp": ts_str,
                    "issue_type": anomaly_flag,
                    "reconciliation_delta": float(kwh_val - (total_interval_kw * 0.25))
                })
            
            telemetry.append({
                "reading_id": r_id,
                "meter_id": met_id,
                "timestamp": ts_str,
                "kwh_consumed": round(kwh_val, 4),
                "kw_demand": round(total_interval_kw, 4)
            })
            
    df_telemetry = pd.DataFrame(telemetry)
    df_ground_truth = pd.DataFrame(ground_truth_anomalies)
    
    tariffs = []
    for idx, ts in enumerate(timestamps[:96]):
        hour = ts.hour
        if hour in:
            window, rate = "PEAK", 0.28
        elif hour in:
            window, rate = "SHOULDER", 0.14
        else:
            window, rate = "OFF_PEAK", 0.07
            
        tariffs.append({
            "tariff_id": f"TAR-2026-{idx:03d}",
            "hour": hour,
            "minute": ts.minute,
            "window_name": window,
            "rate_per_kwh": rate
        })
    df_tariffs = pd.DataFrame(tariffs)
    
    return df_plants, df_meters, df_machines, df_weather, df_batches, df_telemetry, df_tariffs, df_ground_truth

def save_manifest_workspace(data_payloads):
    create_directory_structure()
    for name, df in data_payloads.items():
        df.to_csv(f"data/generated/{name}.csv", index=False)

if __name__ == "__main__":
    p, met, mac, w, b, tel, tar, gt = generate_pipeline(seed=20261022)
    payload = {
        "plants": p, "meters": met, "machines": mac, "weather": w,
        "batches": b, "telemetry": tel, "tariffs": tar, "ground_truth": gt
    }
    save_manifest_workspace(payload)
    print("[SUCCESS] Data generated completely inside data/generated/")
